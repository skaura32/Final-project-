document.addEventListener('DOMContentLoaded', () => {
    const sections = document.querySelectorAll('section');
    const observer = new IntersectionObserver(entries => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add('visible');
            }
        });
    }, { threshold: 0.5 });

    sections.forEach(section => observer.observe(section));

    const contactForm = document.getElementById('contact-form');
    const responseMessage = document.getElementById('response-message');

    contactForm.addEventListener('submit', (e) => {
        e.preventDefault();
        contactForm.reset();
        responseMessage.classList.remove('hidden');
        setTimeout(() => {
            responseMessage.classList.add('hidden');
        }, 5000);
    });
});
let lastScrollTop = 0; 
const header = document.getElementById('header'); // Target header element

window.addEventListener('scroll', function() {
  let currentScroll = window.pageYOffset || document.documentElement.scrollTop;

  // Check if user is scrolling down
  if (currentScroll > lastScrollTop) {
    // Scrolling down, change header background color
    header.style.backgroundColor = '#0288d1'; // New color when scrolling down
  } else {
    // Scrolling up, revert back to original color
    header.style.backgroundColor = '#039be5'; // Original color when scrolling up
  }
  
  // Update the last scroll position
  lastScrollTop = currentScroll <= 0 ? 0 : currentScroll; // Prevent negative scroll values
});
